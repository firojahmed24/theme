=== toptech===
Theme Name: toptech 
Theme URI:http://raytheme.com
Description: toptech Responsive WordPress Theme
Author: themex
Author URI: https://webitrangpur.com/
Version: 1.0.0
Tags: slider.
Text Domain: toptech
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
toptech Responsive WordPress Theme

For more information about toptech please go to webitrangpur.com

== Installation ==

Please see installation guide in Documentation. here https://webitrangpur.com/