<?php
/**
 * Template part for displaying archive posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package toptech
 */

?>
<!-- ARCHIVE QUERY -->
<div class="col-md-6 col-sm-12 col-xs-12  grid-item">
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<div class="toptech-single-blog card border-0 ">					
				<!-- BLOG THUMB -->
				<?php if(has_post_thumbnail()){?>
					<div class="toptech-blog-thumb ">
						<a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail('toptech-blog-default'); ?> </a>
					</div>									
				<?php } ?>
				<!-- BLOG CONTENT -->
				<div class="toptech-blog-content-area ">
					<div class="toptech-blog-meta-top">
						<?php the_category();?>
					</div>
					<!-- BLOG TITLE -->
					<div class="blog-page-title ">
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>			
					</div>
					<!-- BLOG META -->
					<div class="toptech-blog-meta-left ">
							<span><i class="fa fa-clock-o"></i><?php echo get_the_time(get_option('date_format')); ?></span>
						<a class="meta_comments" href="<?php comments_link(); ?>">
							<i class="fa fa-comments-o"></i><?php comments_number( esc_html__('0 Comments','toptech'), esc_html__('1 Comments','toptech'), esc_html__('% Comments','toptech') );?>
						</a>
					</div>														
				</div>	
				
			</div>
		</div> <!--  END SINGLE BLOG -->
</div><!-- #post-## -->